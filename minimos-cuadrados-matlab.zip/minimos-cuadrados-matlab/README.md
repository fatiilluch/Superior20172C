# minimos-cuadrados
Trabajo Práctico Matemática Superior 2C2017. Aproximación por método de mínimos cuadrados
